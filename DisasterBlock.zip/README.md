<h1 align="center">
<img src="https://image.ibb.co/e6OwXH/cloudflare.jpg">
<br />
<img src="https://img.shields.io/badge/XDA-Thread-yellow.svg?longCache=true&style=flat-square"></a><br /><img src="https://img.shields.io/badge/Status-Stable-green.svg?longCache=true&style=flat-square"alt="_time_stamp_" />


This module uses cloudflare family protection DNS to block malware and adult content.
Module for making your #nofap journey easy! #NoP*rnChallenge. 

This module is orginally written by @xerta555 & modified by @0xAshutosh.